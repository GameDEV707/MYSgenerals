# MYS Generals

A real-time strategy base-builder with a DOTA-style hero, built per the specification in
[`../MYSgenerals.md`](../MYSgenerals.md). Trilingual (Uzbek / Russian / English).

> **Build context:** the sandbox this was built in has **no npm registry access**, so the
> spec's prescribed stack (Phaser/React/Vite/Electron/Socket.IO/…) could not be installed.
> The game is therefore implemented **dependency-free** in TypeScript + HTML5 Canvas + WebAudio,
> while preserving the spec's architecture (engine-agnostic authoritative sim, thin render/HUD,
> command + event pipeline). See [`PROGRESS.md`](PROGRESS.md) for the full per-task status.

## Play

The game runs in any modern browser. It must be served over HTTP (opening
`index.html` directly with `file://` won't work, because ES modules need HTTP).
The compiled `dist/` is included, so **you don't need to build anything to play** —
you only need a way to serve the folder.

### Windows

Requires [Node.js](https://nodejs.org) (the only dependency). Then either:

- **Double-click `run.bat`**, or
- in PowerShell: `./run.ps1`, or
- in a terminal: `node serve.mjs`

Then open the printed URL (default <http://localhost:8000/>) in your browser.

> Tip: `run.bat` / `serve.mjs` use only Node's built-in modules — no `npm install`,
> no Python, no bash required.

### macOS / Linux

```bash
cd game
./run.sh            # uses Node if present, else Python 3
# or directly:  node serve.mjs   /   python3 -m http.server 8000
```

### Rebuilding after editing `src/` (optional)

Needs the TypeScript compiler (`npm install -g typescript`).

```bash
# Windows:        build.bat
# macOS/Linux:    ./build.sh      (or: tsc -p tsconfig.json)
```

### Controls

| Action | Input |
|---|---|
| Select / box-select | Left-click / left-drag |
| Move / attack / capture | Right-click |
| Attack-move | `A` then left-click |
| Stop / Hold | `S` / `H` |
| Hero abilities | `Q` `W` `E` `R` (then click target for W/E/R) |
| Control groups | `Ctrl`+`0–9` to set, `0–9` to recall |
| Camera | Arrow keys / screen-edge / middle-mouse drag |
| Zoom | Mouse wheel |
| Build | Select a Miner → category tab → click a building → place |
| Train | Select a production building → click a unit |
| Minimap | Click to jump |
| Pause | `☰` button (top-right) |

## Multiplayer (LAN)

Single-player and local split-screen run entirely in the browser tab (`run.bat` / `serve.mjs`
above, default port 8000). To let **other devices on the same Wi-Fi join a match**, you run the
real host server instead — it serves the game *and* runs the authoritative simulation, and other
phones/laptops join by opening a link or scanning a QR code. No address typing, no `localhost`.

### Host a game

Requires [Node.js](https://nodejs.org). From the `game/` folder:

- **Windows:** double-click **`host.bat`**
- **macOS:** double-click **`host.command`**
- **Linux:** `./host.sh`

(Optional port: `host.bat 3000` / `./host.sh 3000`; default is **3000**.)

This starts the host server and opens the game in your browser — you are **slot 0** and play in
the browser like everyone else (the host machine correctly uses `localhost`). The terminal **and**
the in-game lobby show a **LAN join URL** (e.g. `http://192.168.1.42:3000`), a **room code**, and a
**QR code**.

### Join from another device

On any phone/laptop **on the same Wi-Fi**, either:

- open the **LAN URL** shown on the host (the `http://192.168.x.x:3000` one — **not** `localhost`), or
- **scan the QR code** from the host's lobby screen.

The page auto-connects straight into the lobby (the shared link carries `?room=…` and the host
injects a marker, so no manual "Join" step is needed). A manual **Join Local Game → enter address**
option is still available from the main menu as a fallback.

### First-run notes

- **Same network:** every device must be on the same Wi-Fi / LAN. Guest/AP-isolation networks that
  block device-to-device traffic won't work.
- **Firewall:** the first time you host, your OS may ask whether to allow Node.js to accept incoming
  connections — **allow it** (on Windows tick *Private networks*).

## Project layout

```
game/
├─ index.html, styles.css        # shell + UI styling
├─ serve.mjs                     # zero-dependency static server for LOCAL play (Node built-ins only)
├─ run.bat, run.ps1, run.sh      # local-play launchers (Windows / PowerShell / Unix), port 8000
├─ launch.mjs                    # starts the LAN host server + opens the host's browser
├─ host.bat, host.sh, host.command  # one-click LAN multiplayer host (Win / Linux / macOS), port 3000
├─ build.bat, build.sh           # optional TypeScript compile
├─ src/
│  ├─ constants.ts, types.ts, data.ts, i18n.ts   # shared core (numbers, defs, damage matrix, locales)
│  ├─ sim/        # engine-agnostic authoritative simulation (no DOM): world, grid, map, ai
│  ├─ net/        # protocol, loopback + WebSocket transports, QR encoder
│  ├─ server/     # authoritative Node host: static serving + RFC6455 WebSocket + lobby
│  ├─ render/     # canvas renderer, pooled FX, WebAudio
│  ├─ ui/         # menu + lobby + HUD (DOM overlay)
│  ├─ input.ts    # selection / commands / camera / placement / hotkeys
│  └─ main.ts     # entry: tick loop, wiring, ?room= / served-by-host auto-join
├─ dist/          # compiled ES modules (committed so it runs without a toolchain)
│  └─ server/     # compiled host server (run: node dist/server/host.js [port])
└─ test/          # headless tests (sim, net, host, lobby, input, hud, stress, split, keys, LAN)
```

## Tests

Dependency-free Node test suites (run after `build.sh`):

```bash
NODE_OPTIONS="" node test/smoke.mjs       # simulation: damage matrix, economy, veterancy, win/lose, i18n parity
NODE_OPTIONS="" node test/net.mjs         # LAN protocol: lobby join, ready/start, fog-filtered snapshots
NODE_OPTIONS="" node test/host.mjs        # authoritative host: anti-maphack, command ownership
NODE_OPTIONS="" node test/lobby.mjs       # lobby slot model
NODE_OPTIONS="" node test/lan.mjs         # T25: host serves the game (200) + auto-join marker + slot assignment
# plus: input.mjs, hudlayout.mjs, stress.mjs, split.mjs, keybindings.mjs, kbinput.mjs
```

