// MYS Generals — canonical constants (spec §0 / §26.1). These are the FIXED economy numbers.
export const TILE = 24; // pixels per tile
export const TICK_HZ = 20; // simulation ticks per second (§3.2)
export const TICK_DT = 1 / TICK_HZ; // seconds per tick (0.05)

export const START_SILVER = 15; // §26.1
export const MINER_OUTPUT_INTERVAL = 10; // seconds per +1 silver, per miner (§26.1)
export const SILVER_MINE_SLOTS = 3; // work slots (§26.1)
export const IRON_INTERVAL = 15; // +1 iron / 15 s
export const GOLD_INTERVAL = 30; // +1 gold / 30 s
export const OIL_INTERVAL = 5; // captured oil derrick: +1 silver / 5 s (§12.1)

export const CC_POWER = 5; // Command Center base power (§6.2)
export const POWER_PLANT_OUTPUT = 10; // §26.1

// Brown-out penalties (§6.4)
export const BROWNOUT_PRODUCTION_MULT = 0.5;
export const BROWNOUT_TOWER_FIRE_MULT = 0.6;
export const BROWNOUT_TOWER_RANGE_MULT = 0.8;

// Refunds (§6.6 / §26.1)
export const SELL_REFUND = 0.5;
export const CANCEL_QUEUED_REFUND = 1.0;
export const CANCEL_INPROGRESS_REFUND = 0.5;

export const BUILD_RADIUS = 8; // tiles from an owned building (§7.3)
export const MAX_QUEUE = 8; // §7.3

// Hero (§9 / §26.1)
export const HERO_MAX_LEVEL = 10;
export const HERO_RESPAWN_BASE = 8; // 8 s + 4 s * level
export const HERO_RESPAWN_PER_LEVEL = 4;
export const HERO_XP_PER_LEVEL = 120; // xp needed grows; base step
export const HERO_PASSIVE_XP = 1; // per second trickle

// Veterancy thresholds (§26.4)
export const VET_THRESHOLDS = [0, 100, 300, 700];

// Deposit reserves (§6.3)
export const DEPOSIT_SILVER = 1500;
export const DEPOSIT_IRON = 800;
export const DEPOSIT_GOLD = 400;

export const SNAPSHOT_SECONDS_LIMIT = 0; // unused (single-process)
